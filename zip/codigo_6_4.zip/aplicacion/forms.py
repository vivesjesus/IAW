from flask_wtf import FlaskForm

from wtforms import Form, IntegerField,SelectField,SubmitField,StringField, DecimalField, TextAreaField, FileField
from wtforms.validators import InputRequired



class formArticulo(FlaskForm):                      
	nombre=StringField("Nombre:",validators=[InputRequired("Tienes que introducir el dato")])
	precio=DecimalField("Precio:",default=0,validators=[InputRequired("Tienes que introducir el dato")])
	iva=IntegerField("IVA:",default=21,validators=[InputRequired("Tienes que introducir el dato")])
	descripcion= TextAreaField("Descripción:")
	photo = FileField('Selecciona imagen:')
	stock=IntegerField("Stock:",default=1,validators=[InputRequired("Tienes que introducir el dato")])
	CategoriaId=SelectField("Categoría:",coerce=int)
	submit = SubmitField('Enviar')


class FormCategoria(FlaskForm):
    nombre = StringField("Nombre:",
                        validators=[InputRequired("Tienes que introducir el dato")]
                        )
    submit = SubmitField('Enviar')